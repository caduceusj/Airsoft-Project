using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor.UI;
using UnityEngine;
using UnityEngine.InputSystem.XR;

public enum WeaponType { Shotgun, Rifle, Pistol_1911, Pistol_Glock }

public class Weapon : MonoBehaviour
{
    public WeaponType weaponType;
    public string modelName;      // Nome do modelo da arma
    public float springForce;     // For�a da mola ajust�vel
    public float motorRPM;        // Rota��o do motor (em RPM)
    public float fireRate;        // BBs disparadas por segundo (Rate of Fire)
    public Magazine currentMagazine; // Refer�ncia ao carregador atual


    private BoxCollider areaCollider;

    public float hopUpValue = 0.001f;  // Valor inicial do Hop-up
    public float hopUpMin = 0.0f;      // Valor m�nimo do Hop-up
    public float hopUpMax = 0.01f;     // Valor m�ximo do Hop-up
    public float hopUpStep = 0.0005f;  // Passo de ajuste do Hop-up ao usar o scroll



    public WeaponUI weaponUI;

    public GameObject bbPrefab;  // Prefab da BB
    public Transform muzzle;     // Refer�ncia ao "Muzzle" da arma
    public float shootForce = 1.49f;  // For�a aplicada � BB em joules
    private float bbMass = 0.0002f;   // Massa da BB em kg (0.2g)

    public bool isEquipped = false;

    private Vector3 startPosition;
    private Quaternion startRotation;

    public bool fullAuto = false;

    public bool isFiring = false;
    private float fireCooldown;   // Tempo entre disparos

    private void Start()
    {
        weaponUI = GameObject.Find("Canvas").GetComponent<WeaponUI>();

        startPosition = transform.position;
        startRotation = transform.rotation;
        areaCollider = GetComponent<BoxCollider>();
    }

    void Update()
    {
        if (isEquipped)
        {
            AdjustHopUp();
        }

        if(weaponUI != null && isEquipped)
        {
            weaponUI.UpdateWeaponUI(modelName, currentMagazine.currentBBs, currentMagazine.capacity, fullAuto, hopUpValue);
        }
        else
        {
            weaponUI.UpdateWeaponUI("Equipe uma Arma", 0, 0, false, 0f);
        }


        if (fireCooldown > 0)
        {
            fireCooldown -= Time.deltaTime;
        }

        if(Input.GetKeyDown(KeyCode.F) && weaponType != WeaponType.Shotgun)
        {
            fullAuto = !fullAuto;
        }
        if(Input.GetKeyDown(KeyCode.Q) && isEquipped)
        {
            Destroy(this.gameObject);
        }

        // Disparo ao apertar o bot�o de fogo (Fire1 � o bot�o esquerdo do mouse)
        if (Input.GetButtonDown("Fire1") && fireCooldown <= 0 && isEquipped && currentMagazine.currentBBs > 0)
        {
            currentMagazine.currentBBs--;
            if (fullAuto) { isFiring = true; }
            else if(weaponType == WeaponType.Shotgun)
            {
                for (int i = 0; i < 10; i++)
                {
                    Fire();
                }
            }
            else { Fire(); }
           
        }
        else if (Input.GetButtonUp("Fire1"))
        {
            isFiring = false;
        }
        else if (isFiring && fireCooldown <= 0 && currentMagazine.currentBBs > 0)
        {
            currentMagazine.currentBBs--;
            Fire();  // Chamar a fun��o de disparo
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && (GameObject.Find("GunSlot").transform.childCount == 0))
        {
            Debug.Log("Player Enter");
            if (weaponType == WeaponType.Rifle)
            {
                GameObject WeaponAux = Instantiate(this.gameObject);
                WeaponAux.transform.SetParent(GameObject.Find("GunSlot").transform, true);
                WeaponAux.transform.localPosition = new Vector3(1f, -0.5f, -0.1f);
                WeaponAux.transform.rotation = new Quaternion(0f, 0f, 0f, 0f);
                WeaponAux.transform.localScale = new Vector3(0.5f, 0.5f,0.5f);
                WeaponAux.GetComponent<Weapon>().isEquipped = true;
            }
            else if(weaponType == WeaponType.Pistol_Glock) {
                GameObject WeaponAux = Instantiate(this.gameObject);
                WeaponAux.transform.SetParent(GameObject.Find("GunSlot").transform, true);
                WeaponAux.transform.localPosition = new Vector3(0f, 0f, 0f);
                WeaponAux.transform.rotation = new Quaternion(0f, 0f, 0f, 0f);
                WeaponAux.transform.localScale = new Vector3(0.3f, 0.1f, 0.1f);
                WeaponAux.GetComponent<Weapon>().isEquipped = true;
            }
            if (weaponType == WeaponType.Shotgun)
            {
                GameObject WeaponAux = Instantiate(this.gameObject);
                WeaponAux.transform.SetParent(GameObject.Find("GunSlot").transform, true);
                WeaponAux.transform.localPosition = new Vector3(1f, -0.25f, -0.2f);
                WeaponAux.transform.rotation = new Quaternion(0f, 0f, 0f, 0f);
                WeaponAux.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
                WeaponAux.GetComponent<Weapon>().isEquipped = true;
                
            }
        }
        
    }

    void AdjustHopUp()
    {
        // Obter o valor do scroll do mouse
        float scroll = Input.GetAxis("Mouse ScrollWheel");

        // Ajustar o Hop-up baseado no scroll, dentro dos limites m�nimo e m�ximo
        hopUpValue = Mathf.Clamp(hopUpValue + scroll * hopUpStep, hopUpMin, hopUpMax);

        // Exibir o valor do Hop-up no Console para depura��o
       // Debug.Log("Hop-up value: " + hopUpValue);
    }

    void Fire()
    {
        if (currentMagazine != null && currentMagazine.currentBBs > 0)
        {
            if (currentMagazine != null && currentMagazine.currentBBs > 0)
            {
                // Consome uma BB do carregador
                fireCooldown = 1f / fireRate; // Define o tempo entre os disparos baseado no fireRate

                // Instanciar a BB na posi��o do muzzle (cano da arma)
                GameObject bb = Instantiate(bbPrefab, muzzle.position, muzzle.rotation);

                // Configurar a massa da BB com base no carregador atual
                bbMass = currentMagazine.bbMass;

                // Calcular a velocidade inicial da BB com base na for�a de disparo e na massa da BB
                float initialVelocity = Mathf.Sqrt((2 * shootForce) / bbMass);

                // Aplicar a for�a na dire��o do cano
                Rigidbody rb = bb.GetComponent<Rigidbody>();
                rb.mass = bbMass;  // Define a massa no Rigidbody
                rb.AddForce(muzzle.forward * initialVelocity*30, ForceMode.VelocityChange);

                // Logar a velocidade inicial no Console para verificar
                Debug.Log("Velocidade inicial da BB: " + initialVelocity + " m/s");

                // Adicionar script que simula o efeito Magnus (Hop-up)
                bb.GetComponent<BBController>().Initialize(rb, hopUpValue);

                // Destruir o proj�til ap�s um tempo
                Destroy(bb, 5f);
            }
        }
    }
}
