using UnityEngine;

public class AirsoftGunScript : MonoBehaviour
{
    public GameObject bbPrefab;  // Prefab da BB
    public Transform muzzle;     // Refer�ncia ao "Muzzle" da arma
    public float shootForce = 1.49f;  // For�a aplicada � BB em joules
    private float bbMass = 0.0002f;   // Massa da BB em kg (0.2g)





    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            ShootBB();
        }
    }

    void ShootBB()
    {
        // Instanciar a BB na posi��o do Muzzle
        GameObject bb = Instantiate(bbPrefab, muzzle.position, muzzle.rotation);

        // Calcular a velocidade inicial da BB em metros por segundo
        float initialVelocity = Mathf.Sqrt((2 * shootForce) / bbMass);


        // Aplicar a for�a na dire��o do cano
        Rigidbody rb = bb.GetComponent<Rigidbody>();
        rb.AddForce(muzzle.forward * initialVelocity, ForceMode.VelocityChange);

        // Logar a velocidade inicial no Console para verificar
        Debug.Log("Velocidade inicial da BB: " + initialVelocity + " m/s");
    }
}
