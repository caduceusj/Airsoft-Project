using UnityEngine;

public class BBController : MonoBehaviour
{
    private Rigidbody rb;
    private float backspinDrag;


    public void Initialize(Rigidbody rigidbody, float backspin)
    {
        Debug.Log("BulletINitialzed");
        rb = rigidbody;
        backspinDrag = backspin;
    }

    private void FixedUpdate()
    {
        // Simular o efeito Magnus (Hop-up)
        Vector3 velocity = rb.velocity;
        float liftForceMagnitude = Mathf.Sqrt(velocity.x * velocity.x + velocity.z * velocity.z) * backspinDrag;

        // Calcular a dire��o da for�a perpendicular � dire��o do movimento
        Vector3 liftDirection = Vector3.Cross(velocity, Vector3.forward).normalized;

        // Aplicar a for�a de sustenta��o (lift force)
        rb.AddForce(liftDirection * liftForceMagnitude, ForceMode.Force);
    }
}
