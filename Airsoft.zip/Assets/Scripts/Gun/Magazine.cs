using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Magazine : MonoBehaviour
{

    protected BoxCollider boxCollider;

    public WeaponType magazineType;   // O tipo do carregador (conforme a arma)
    public int capacity;              // Quantidade m�xima de BBs no carregador
    public int currentBBs;            // Quantidade atual de BBs no carregador
    public float bbMass;              // Massa atual das BBs no carregador

    public Weapon weaponAux;

    private void Start()
    {
        boxCollider = GameObject.Find("WeaponBox").GetComponent<BoxCollider>();

    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {

            weaponAux = other.transform.Find("PlayerCameraRoot/GunSlot").transform.GetChild(0).gameObject.GetComponent<Weapon>();
            Debug.Log("FOUND WEAPON");
            print(weaponAux.name);
            print(magazineType);

            if (weaponAux != null && weaponAux.weaponType == magazineType)
            {
                currentBBs = capacity;
                weaponAux.currentMagazine = this;
                Debug.Log("AMOGUS");
            }
        }
    }
}

