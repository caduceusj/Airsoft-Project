using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wall : MonoBehaviour
{

    BoxCollider wall;
    public Material tempMaterial;
    public Material originalMaterial;
    public MeshRenderer meshRenderer;
    // Start is called before the first frame update
    void Start()
    {   
        meshRenderer = GetComponent<MeshRenderer>();
        wall = GetComponent<BoxCollider>();
        originalMaterial = meshRenderer.material;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("BB"))
        {
            Destroy(other.gameObject);
            meshRenderer.material = tempMaterial;
            StartCoroutine(colorChange());
        }
        
    }

    IEnumerator colorChange()
    {
        yield return new WaitForSeconds(5f);
        meshRenderer.material = originalMaterial;
    }
}
