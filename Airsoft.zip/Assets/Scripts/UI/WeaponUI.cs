using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class WeaponUI : MonoBehaviour
{
    public TextMeshProUGUI weaponNameText; // Texto que exibe o nome da arma.
    public TextMeshProUGUI ammoText; // Texto que exibe muni��o atual / capacidade do pente.
    public TextMeshProUGUI fireModeText; // Texto que exibe o modo de disparo (Full auto ou Semi).
    public TextMeshProUGUI hopUpText;
    // Fun��o para atualizar a interface da arma
    public void UpdateWeaponUI(string weaponName, int currentAmmo, int maxAmmo, bool isFullAuto, float hopUp)
    {

        weaponNameText.text = weaponName; // Nome da arma.
        ammoText.text = currentAmmo + " / " + maxAmmo; // Muni��o atual / Capacidade do pente.
        fireModeText.text = isFullAuto ? "Full Auto" : "Semi-Auto"; // Modo de disparo.
        hopUpText.text = "Hop Up: "+ hopUp.ToString();
    }
}
